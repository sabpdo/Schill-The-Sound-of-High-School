function f() {}
'use strict';
document.addEventListener('DOMContentLoaded', () => {
	const stickyArea = document.querySelector(
		'#stickies-container'
	);

	const createStickyButton = document.querySelector(
		'#createsticky'
	);

	const stickyTitleInput = document.querySelector('#stickytitle');
	const stickyTextInput = document.querySelector('#stickytext');

	const deleteSticky = e => {
		e.target.parentNode.remove();
	};

	let isDragging = false;
	let dragTarget;

	let lastOffsetX = 0;
	let lastOffsetY = 0;

	function drag(e) {
		if (!isDragging) return;
		dragTarget.style.left = e.clientX - lastOffsetX + 'px';
		dragTarget.style.top = e.clientY - lastOffsetY + 'px';
	}

	function createSticky() {
		const newSticky = document.createElement('div');
		const html = `<h3>${stickyTitleInput.value.replace(
     /<\/?[^>]+(>|$)/g,
     ''
   )}</h3><p>${stickyTextInput.value
   .replace(/<\/?[^>]+(>|$)/g, '')
   .replace(
     /\r\n|\r|\n/g,
     '<br />'
   )}</p><span class="deletesticky">&times;</span>`;
		newSticky.classList.add('drag', 'sticky');
		newSticky.innerHTML = html;
		newSticky.style.backgroundColor = randomColor();
		stickyArea.append(newSticky);
		positionSticky(newSticky);
		applyDeleteListener();
		clearStickyForm();
	}

	function clearStickyForm() {
		stickyTitleInput.value = '';
		stickyTextInput.value = '';
	}

	function positionSticky(sticky) {
		sticky.style.left =
			window.innerWidth / 2 -
			sticky.clientWidth / 2 +
			(-100 + Math.round(Math.random() * 50)) +
			'px';
		sticky.style.top =
			window.innerHeight / 2 -
			sticky.clientHeight / 2 +
			(-100 + Math.round(Math.random() * 50)) +
			'px';
	}

	function editSticky() {}

	function stripHtml(text) {
		return text.replace(/<\/?[^>]+(>|$)/g, '');
	}

	function randomColor() {
		var colors = ['#FFFFFF', '#E8D9D5', '#CFB997'];
		var random_color = colors[Math.floor(Math.random() * colors.length)];
		return random_color;
	}

	function applyDeleteListener() {
		let deleteStickyButtons = document.querySelectorAll(
			'.deletesticky'
		);
		deleteStickyButtons.forEach(dsb => {
			dsb.removeEventListener('click', deleteSticky, false);
			dsb.addEventListener('click', deleteSticky);
		});
	}

	window.addEventListener('mousedown', e => {
		if (!e.target.classList.contains('drag')) {
			return;
		}
		dragTarget = e.target;
		dragTarget.parentNode.append(dragTarget);
		lastOffsetX = e.offsetX;
		lastOffsetY = e.offsetY;
		// console.log(lastOffsetX, lastOffsetY);
		isDragging = true;
	});
	window.addEventListener('mousemove', drag);
	window.addEventListener('mouseup', () => (isDragging = false));

	createStickyButton.addEventListener('click', createSticky);
	applyDeleteListener();
});

// 10 minutes from now
var time_in_minutes = 25;
var current_time = Date.parse(new Date());
var deadline = new Date(current_time + time_in_minutes * 60 * 1000);

function time_remaining(endtime) {
	var t = Date.parse(endtime) - Date.parse(new Date());
	var seconds = Math.floor((t / 1000) % 60);
	var minutes = Math.floor((t / 1000 / 60) % 60);
	var hours = Math.floor((t / (1000 * 60 * 60)) % 24);
	var days = Math.floor(t / (1000 * 60 * 60 * 24));
	return { 'total': t, 'days': days, 'hours': hours, 'minutes': minutes, 'seconds': seconds };
}

var timeinterval;

function run_clock(id, endtime) {
	var clock = document.getElementById(id);

	function update_clock() {
		var t = time_remaining(endtime);
		clock.innerHTML = 'minutes: ' + t.minutes + '<br>seconds: ' + t.seconds;
		if (t.total <= 0) { clearInterval(timeinterval); }
	}
	update_clock(); // run function once at first to avoid delay
	timeinterval = setInterval(update_clock, 1000);
}
run_clock('clockdiv', deadline);

var paused = false; // is the clock paused?
var time_left; // time left on the clock when paused

function pause_clock() {
	if (!paused) {
		paused = true;
		clearInterval(timeinterval); // stop the clock
		time_left = time_remaining(deadline)
			.total; // preserve remaining time
	}
}

function resume_clock() {
	if (paused) {
		paused = false;

		// update the deadline to preserve the amount of time remaining
		deadline = new Date(Date.parse(new Date()) + time_left);

		// start the clock
		run_clock('clockdiv', deadline);
	}
}

// handle pause and resume button clicks
document.getElementById('pause')
	.onclick = pause_clock;
document.getElementById('resume')
	.onclick = resume_clock;

(document)
.ready(function () {
	all_notes = $("li a");

	all_notes.on("keyup", function () {
		note_title = $(this)
			.find("h2")
			.text();
		note_content = $(this)
			.find("p")
			.text();

		item_key = "list_" + $(this)
			.parent()
			.index();

		data = {
			title: note_title,
			content: note_content
		};

		window.localStorage.setItem(item_key, JSON.stringify(data));
	});

	all_notes.each(function (index) {
		data = JSON.parse(window.localStorage.getItem("list_" + index));

		if (data !== null) {
			note_title = data.title;
			note_content = data.content;

			$(this)
				.find("h2")
				.text(note_title);
			$(this)
				.find("p")
				.text(note_content);
		}
	});
});